package com.example.mentalhealth.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.example.mentalhealth.R

@Composable
fun TranstornosMentaisScreen(navController: NavHostController) {
    Box(modifier = Modifier.fillMaxSize()) {
        Image(
            painter = painterResource(id = R.drawable.fundo),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0x664D6E73))
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "Definição e Conceito",
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Bold,
                    color = Color.Black
                )
            )

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = "Transtornos Mentais",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = Color.Black
                )
            )
            Text(
                text = "Veja os principais transtornos mentais apresentados em alunos",
                style = MaterialTheme.typography.bodySmall.copy(
                    color = Color.Black
                )
            )

            Spacer(modifier = Modifier.height(24.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.95f))
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.Start
                ) {
                    TranstornoItem(
                        titulo = "Depressão",
                        descricao = "Tristeza persistente, perda de interesse e sintomas físicos como fadiga. Pode afetar desempenho escolar e relacionamentos.",
                        onSaibaMaisClick = {
                            // Ação futura ao clicar em saiba mais Depressão
                        }
                    )

                    TranstornoItem(
                        titulo = "Ansiedade",
                        descricao = "Preocupação excessiva, tensão muscular, suor e sensação de sufocamento. É comum em situações escolares desafiadoras.",
                        onSaibaMaisClick = {
                            // Ação futura ao clicar em saiba mais Ansiedade
                        }
                    )

                    TranstornoItem(
                        titulo = "Transtornos Alimentares",
                        descricao = "Como anorexia e bulimia. Envolvem comportamentos alimentares prejudiciais relacionados à autoimagem.",
                        onSaibaMaisClick = {
                            // Ação futura ao clicar em saiba mais Transtornos Alimentares
                        }
                    )

                    TranstornoItem(
                        titulo = "Transtorno de Pânico",
                        descricao = "Crises súbitas de medo intenso com sintomas físicos como dor no peito, tontura e taquicardia.",
                        onSaibaMaisClick = {
                            // Ação futura ao clicar em saiba mais Transtorno de Pânico
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun TranstornoItem(
    titulo: String,
    descricao: String,
    onSaibaMaisClick: () -> Unit = {}
) {
    Column(modifier = Modifier.padding(bottom = 16.dp)) {
        Text(
            text = "• $titulo",
            fontWeight = FontWeight.Bold,
            fontSize = 18.sp,
            color = Color.Black
        )
        Text(
            text = descricao,
            fontSize = 14.sp,
            color = Color.DarkGray
        )

        Spacer(modifier = Modifier.height(4.dp))

        Text(
            text = "Saiba mais",
            color = MaterialTheme.colorScheme.primary,
            fontWeight = FontWeight.SemiBold,
            fontSize = 14.sp,
            modifier = Modifier
                .align(Alignment.End)
                .clip(RoundedCornerShape(8.dp))
                .clickable { onSaibaMaisClick() }
                .padding(horizontal = 8.dp, vertical = 4.dp)
        )
    }
}


@Composable
fun TranstornoItem(titulo: String, descricao: String) {
    Column(modifier = Modifier.padding(bottom = 16.dp)) {
        Text(
            text = "• $titulo",
            fontWeight = FontWeight.Bold,
            fontSize = 18.sp,
            color = Color.Black
        )
        Text(
            text = descricao,
            fontSize = 14.sp,
            color = Color.DarkGray
        )
    }
}
