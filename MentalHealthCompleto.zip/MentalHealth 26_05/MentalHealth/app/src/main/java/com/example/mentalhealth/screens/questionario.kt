package com.example.mentalhealth.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.mentalhealth.R
import com.example.mentalhealth.ui.theme.MentalHealthTheme
import androidx.navigation.NavHostController
import androidx.navigation.compose.rememberNavController

enum class RespostaSimNao {
    SIM, NAO
}

data class PerguntaSimNao(
    val texto: String,
    val resposta: RespostaSimNao? = null
)

val perguntasSaudeMental = listOf(
    PerguntaSimNao("1. Você tem se sentido desmotivado nos últimos dias?"),
    PerguntaSimNao("2. Tem dificuldade para dormir ou manter o sono?"),
    PerguntaSimNao("3. Você sente cansaço excessivo mesmo após descanso?"),
    PerguntaSimNao("4. Sente medo ou preocupação excessiva sem motivo claro?"),
    PerguntaSimNao("5. Já evitou atividades por medo de julgamento ou ansiedade?"),
    PerguntaSimNao("6. Sente-se frequentemente triste ou sem esperança?"),
    PerguntaSimNao("7. Já teve crises de choro sem motivo aparente?"),
    PerguntaSimNao("8. Tem dificuldades de concentração em tarefas simples?"),
    PerguntaSimNao("9. Percebeu mudanças no apetite recentemente?"),
    PerguntaSimNao("10. Já pensou em desistir de tudo, mesmo que por pouco tempo?")
)

@Composable
fun QuestScreen(navController: NavHostController) {
    val respostas = remember {
        mutableStateListOf<RespostaSimNao?>().apply {
            repeat(perguntasSaudeMental.size) { add(null) }
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Image(
            painter = painterResource(id = R.drawable.fundo),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0x664D6E73))
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Conteúdo rolável ocupa espaço disponível
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),  // <-- ocupa o máximo de espaço para scroll funcionar direito
                shape = RoundedCornerShape(24.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.95f))
            ) {
                Column(
                    modifier = Modifier
                        .verticalScroll(rememberScrollState())
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Autoavaliação de Saúde Mental",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        ),
                        color = Color.Black
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    perguntasSaudeMental.forEachIndexed { index, pergunta ->
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0xFFF0F0F0), RoundedCornerShape(12.dp))
                                .padding(12.dp)
                        ) {
                            Text(
                                text = pergunta.texto,
                                style = MaterialTheme.typography.bodySmall.copy(fontSize = 14.sp),
                                color = Color.Black
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(
                                horizontalArrangement = Arrangement.SpaceEvenly,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                listOf("Sim" to RespostaSimNao.SIM, "Não" to RespostaSimNao.NAO).forEach { (label, value) ->
                                    Button(
                                        onClick = { respostas[index] = value },
                                        shape = RoundedCornerShape(50),
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = if (respostas[index] == value)
                                                Color(0xFF0D47A1) else Color(0xFFB0BEC5)
                                        ),
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                        modifier = Modifier.height(36.dp)
                                    ) {
                                        Text(label, color = Color.White, fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Button(
                onClick = {
                    // Ação ao enviar respostas
                },
                shape = RoundedCornerShape(50),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(44.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0D47A1))
            ) {
                Text("ENVIAR RESPOSTAS", color = Color.White, fontSize = 14.sp)
            }
        }
    }
}


@Preview(showBackground = true, showSystemUi = true)
@Composable
fun QuestScreenPreview() {
    MentalHealthTheme {
        val navController = rememberNavController()
        QuestScreen(navController = navController)
    }
}
