package com.example.mentalhealth.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.mentalhealth.R
import com.example.mentalhealth.ui.theme.MentalHealthTheme
import androidx.navigation.NavHostController
import androidx.navigation.compose.rememberNavController


@Composable
fun AgendamentoScreen(navController: NavHostController) {
    val diasSemana = listOf("Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb")
    val datas = listOf("1", "2", "3", "4", "5", "6", "7")
    val horariosPorDia = listOf(
        listOf(), // Domingo
        listOf(), // Segunda
        listOf("16:00"), // Terça
        listOf("8:00", "9:00", "10:00", "15:00"), // Quarta
        listOf("10:00", "11:00", "12:00", "15:00", "16:00"), // Quinta
        listOf("11:00", "14:00", "15:00", "17:00"), // Sexta
        listOf()  // Sábado
    )

    var diaSelecionado by remember { mutableStateOf(2) } // Terça como padrão
    var horarioSelecionado by remember { mutableStateOf("") }

    Box(modifier = Modifier.fillMaxSize()) {
        Image(
            painter = painterResource(id = R.drawable.fundo),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0x664D6E73))
        )

        Card(
            modifier = Modifier
                .align(Alignment.Center)
                .fillMaxWidth(0.95f),
            shape = RoundedCornerShape(24.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.95f))
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Marque sua consulta agora.",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.Black
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Navegação entre semanas
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { /* ação voltar */ }) {
                        Icon(
                            imageVector = Icons.Filled.ArrowBack,
                            contentDescription = "Voltar",
                            tint = Color.Black
                        )
                    }

                    Button(
                        onClick = { /* ação botão Hoje */ },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE0E0E0)),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Text("Hoje", color = Color.Black)
                    }

                    IconButton(onClick = { /* ação avançar */ }) {
                        Icon(
                            imageVector = Icons.Filled.ArrowForward,
                            contentDescription = "Avançar",
                            tint = Color.Black
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(diasSemana.size) { index ->
                        Column(
                            modifier = Modifier
                                .width(100.dp)
                                .clickable {
                                    diaSelecionado = index
                                    horarioSelecionado = ""
                                }
                                .background(
                                    if (index == diaSelecionado) Color(0xFF1976D2) else Color(0xFFF0F0F0),
                                    RoundedCornerShape(12.dp)
                                )
                                .padding(8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = diasSemana[index],
                                color = if (index == diaSelecionado) Color.White else Color.Black,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center
                            )
                            Text(
                                text = datas[index],
                                color = if (index == diaSelecionado) Color.White else Color.Black
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            horariosPorDia[index].forEach { hora ->
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 2.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(
                                            if (horarioSelecionado == hora) Color(0xFF1565C0) else Color(0xFFE0E0E0)
                                        )
                                        .clickable {
                                            horarioSelecionado = hora
                                        }
                                        .padding(horizontal = 8.dp, vertical = 6.dp)
                                ) {
                                    Text(
                                        text = "+",
                                        color = if (horarioSelecionado == hora) Color.White else Color.Black,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = hora,
                                        color = if (horarioSelecionado == hora) Color.White else Color.Black
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                Button(
                    onClick = {
                        // ação para continuar
                    },
                    shape = RoundedCornerShape(50),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0D47A1))
                ) {
                    Text("Continuar", color = Color.White)
                }
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun AgendamentoScreenPreview() {
    MentalHealthTheme {
        val navController = rememberNavController()
        AgendamentoScreen(navController = navController)
    }
}
