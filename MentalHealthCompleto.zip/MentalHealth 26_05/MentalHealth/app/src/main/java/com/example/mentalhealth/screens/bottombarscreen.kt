package com.example.mentalhealth.screens

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.ui.graphics.vector.ImageVector

enum class BottomBarScreen(val route: String, val title: String, val icon: ImageVector) {
    Definicao("definicao", "Transtornos", Icons.Default.Info),
    Questionario("questionario", "Avaliação", Icons.Default.QuestionAnswer),
    Agenda("agenda", "Agenda", Icons.Default.DateRange),
    Ecos("ecos", "Integrantes", Icons.Default.People)
}
