package com.example.mentalhealth.screens

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController

@Composable
fun BottomNavContainer(mainNavController: NavHostController) {
    val bottomNavController = rememberNavController()

    Scaffold(
        bottomBar = {
            BottomNavigationBar(navController = bottomNavController)
        }
    ) { innerPadding ->
        NavHost(
            navController = bottomNavController,
            startDestination = BottomBarScreen.Definicao.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(BottomBarScreen.Definicao.route) {
                TranstornosMentaisScreen(navController = mainNavController)
            }
            composable(BottomBarScreen.Questionario.route) {
                QuestScreen(navController = mainNavController)
            }
            composable(BottomBarScreen.Agenda.route) {
                AgendamentoScreen(navController = mainNavController)
            }
            composable(BottomBarScreen.Ecos.route) {
                IntegrantesScreen(navController = mainNavController)
            }
        }
    }
}
