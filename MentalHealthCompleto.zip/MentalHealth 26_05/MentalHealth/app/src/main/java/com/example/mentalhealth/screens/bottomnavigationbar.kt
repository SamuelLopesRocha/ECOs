package com.example.mentalhealth.screens

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.navigation.NavController
import androidx.navigation.compose.currentBackStackEntryAsState

@Composable
fun BottomNavigationBar(navController: NavController) {
    val navBackStackEntry = navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry.value?.destination?.route

    NavigationBar(
        containerColor = Color(0xFF0D47A1), // Azul escuro
        contentColor = Color.White
    ) {
        BottomBarScreen.values().forEach { screen ->
            NavigationBarItem(
                selected = currentRoute == screen.route,
                onClick = {
                    if (currentRoute != screen.route) {
                        navController.navigate(screen.route) {
                            popUpTo(navController.graph.startDestinationId) {
                                saveState = true
                            }
                            launchSingleTop = true
                            restoreState = true
                        }
                    }
                },
                icon = {
                    Icon(
                        imageVector = screen.icon,
                        contentDescription = screen.title,
                        tint = if (currentRoute == screen.route) Color.White else Color.LightGray
                    )
                },
                label = {
                    Text(
                        text = screen.title,
                        color = if (currentRoute == screen.route) Color.White else Color.LightGray
                    )
                },
                alwaysShowLabel = true
            )
        }
    }
}
